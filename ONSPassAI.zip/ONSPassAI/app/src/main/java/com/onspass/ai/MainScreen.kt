package com.onspass.ai

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

@Composable
fun AssistantApp(vm: AssistantViewModel) {
    var settings by remember { mutableStateOf(false) }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B0B1A), Color(0xFF16113A), Color(0xFF05050D))))
            .systemBarsPadding()
    ) {
        if (settings) {
            BackHandler { settings = false }
            SettingsScreen(vm) { settings = false }
        } else {
            MainScreen(vm) { settings = true }
        }
    }
}

@Composable
fun MainScreen(vm: AssistantViewModel, onSettings: () -> Unit) {
    val listState = rememberLazyListState()
    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(max(0, vm.messages.size - 1))
    }
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("ONS PASS AI", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = Color.White) }
        }
        StatusChip(vm.status, vm.lang)
        if (vm.messages.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    vm.lang.t("Tap the mic and speak.", "माइक दबाकर बोलें।", "مائیک دبا کر بولیں۔"),
                    color = Color(0xFF8E8AB8), fontSize = 16.sp
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) { items(vm.messages) { Bubble(it) } }
        }
        if (vm.partial.isNotBlank()) {
            Text(vm.partial, color = Color(0xFFB9B4FF), fontSize = 15.sp, modifier = Modifier.padding(bottom = 6.dp))
        }
        vm.pendingText?.let { ConfirmCard(it, vm.lang, vm::confirm, vm::cancel) }
        VoiceWaves(active = vm.status == Status.Listening || vm.status == Status.Speaking)
        MicButton(vm.status, vm::onMicClick)
    }
}

@Composable
fun StatusChip(status: Status, l: Lang) {
    val (text, color) = when (status) {
        Status.Idle -> l.t("Ready", "तैयार", "تیار") to Color(0xFF6E6A99)
        Status.Listening -> l.t("Listening…", "सुन रहा हूँ…", "سن رہا ہوں…") to Color(0xFF3DDC97)
        Status.Thinking -> l.t("Thinking…", "सोच रहा हूँ…", "سوچ رہا ہوں…") to Color(0xFFFFC857)
        Status.Speaking -> l.t("Speaking…", "बोल रहा हूँ…", "بول رہا ہوں…") to Color(0xFF7B5CFF)
    }
    Row(
        Modifier.padding(top = 4.dp).clip(RoundedCornerShape(50)).background(Color(0x22FFFFFF)).padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(text, color = Color.White, fontSize = 14.sp)
    }
}

@Composable
fun Bubble(m: Msg) {
    val bg = when {
        m.notice -> Color(0x22FFFFFF)
        m.fromUser -> Color(0xFF4B2FD6)
        else -> Color(0xFF241F4A)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Text(
            m.text,
            color = if (m.notice) Color(0xFFB9B4FF) else Color.White,
            fontSize = if (m.notice) 13.sp else 16.sp,
            modifier = Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(16.dp)).background(bg).padding(horizontal = 14.dp, vertical = 10.dp)
        )
    }
}

@Composable
fun ConfirmCard(text: String, l: Lang, onYes: () -> Unit, onNo: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF2B2459)).padding(14.dp)
    ) {
        Text(text, color = Color.White, fontSize = 15.sp)
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onYes) { Text(l.t("Confirm", "हाँ", "ہاں")) }
            OutlinedButton(onClick = onNo) { Text(l.t("Cancel", "रद्द करें", "منسوخ"), color = Color.White) }
        }
    }
}

@Composable
fun VoiceWaves(active: Boolean) {
    val t = rememberInfiniteTransition(label = "waves")
    val phase by t.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    Canvas(Modifier.fillMaxWidth().height(56.dp)) {
        val n = 32
        val gap = size.width / n
        for (i in 0 until n) {
            val amp = if (active) 0.2f + 0.8f * abs(sin(phase + i * 0.45f)) else 0.07f
            val h = size.height * amp
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFFA796FF), Color(0xFF4B2FD6))),
                topLeft = Offset(i * gap + gap * 0.25f, (size.height - h) / 2),
                size = Size(gap * 0.5f, h),
                cornerRadius = CornerRadius(gap / 4)
            )
        }
    }
}

@Composable
fun MicButton(status: Status, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "pulse")
    val pulse by inf.animateFloat(
        initialValue = 1f, targetValue = 1.18f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p"
    )
    val scale = if (status == Status.Listening) pulse else 1f
    Box(Modifier.size(170.dp), contentAlignment = Alignment.Center) {
        if (status == Status.Listening) {
            Box(Modifier.size(150.dp).scale(scale).background(Color(0x334B2FD6), CircleShape))
        }
        Box(
            Modifier
                .size(128.dp)
                .shadow(28.dp, CircleShape, ambientColor = Color(0xFF7B5CFF), spotColor = Color(0xFF7B5CFF))
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFFA796FF), Color(0xFF5B3FE8), Color(0xFF241A7A)),
                        center = Offset(110f, 90f), radius = 260f
                    ), CircleShape
                )
                .border(2.dp, Brush.verticalGradient(listOf(Color(0x88FFFFFF), Color.Transparent)), CircleShape)
                .clip(CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (status == Status.Idle) Icons.Filled.Mic else Icons.Filled.Stop,
                contentDescription = "Microphone",
                tint = Color.White,
                modifier = Modifier.size(56.dp)
            )
        }
    }
}
