package com.onspass.ai

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class TtsManager(ctx: Context, private val onDone: () -> Unit) {
    private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx) { status -> ready = status == TextToSpeech.SUCCESS }
    }

    /** Returns false if nothing will be spoken (engine not ready or voice for the language is missing). */
    fun speak(text: String, lang: Lang): Boolean {
        val t = tts ?: return false
        if (!ready) return false
        val loc = Locale.forLanguageTag(lang.tag)
        if (t.isLanguageAvailable(loc) < TextToSpeech.LANG_AVAILABLE) return false
        t.language = loc
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { this@TtsManager.onDone() }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { this@TtsManager.onDone() }
        })
        return t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ons") == TextToSpeech.SUCCESS
    }

    fun stop() { tts?.stop() }
    fun shutdown() { tts?.stop(); tts?.shutdown(); tts = null }
}
