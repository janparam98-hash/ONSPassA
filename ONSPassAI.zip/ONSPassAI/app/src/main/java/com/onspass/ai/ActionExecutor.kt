package com.onspass.ai

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings

class ActionExecutor(private val ctx: Context) {

    data class Result(val ok: Boolean, val message: String)
    private class Resolved(val number: String?, val error: String?, val notFound: Boolean = false)

    private val waPackages = listOf("com.whatsapp", "com.whatsapp.w4b")
    private val ttPackages = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")

    fun needsConfirmation(a: Action) = a.type == "call" || a.type == "whatsapp"

    fun describe(a: Action, l: Lang): String {
        val who = a.contact.ifBlank { l.t("a contact you choose", "आपके चुने हुए संपर्क", "آپ کے منتخب رابطے") }
        return when (a.type) {
            "call" -> l.t("Call ${a.contact}?", "${a.contact} को कॉल करूँ?", "${a.contact} کو کال کروں؟")
            else -> l.t(
                "Open WhatsApp with this message ready for $who: \"${a.text}\". You will tap Send yourself. Continue?",
                "$who के लिए WhatsApp में यह संदेश तैयार करूँ: \"${a.text}\"। भेजने के लिए आप खुद Send दबाएँगे। आगे बढ़ूँ?",
                "$who کے لیے WhatsApp میں یہ پیغام تیار کروں: \"${a.text}\"۔ بھیجنے کے لیے آپ خود Send دبائیں گے۔ آگے بڑھوں؟"
            )
        }
    }

    suspend fun execute(a: Action, l: Lang, ensure: suspend (String) -> Boolean): Result = when (a.type) {
        "open_app" -> openApp(a.app, l)
        "google_search" -> search(a.query, l)
        "open_url" -> openUrl(a.query, l)
        "open_settings" -> openSettings(a.setting, l)
        "show_contacts" -> showContacts(l)
        "call" -> call(a, l, ensure)
        "whatsapp" -> whatsapp(a, l, ensure)
        "tiktok" -> tiktok(l)
        "type_text" -> typeText(a.text, l)
        "copy_text" -> copyText(a.text, l)
        else -> Result(true, l.t("Done", "ठीक है", "ٹھیک ہے"))
    }

    // ---------- helpers ----------
    private fun launch(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true
    } catch (e: Exception) { false }

    private fun installed(pkg: String) = try { ctx.packageManager.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }

    private fun fail(l: Lang, en: String, hi: String, ur: String) = Result(false, l.t(en, hi, ur))

    // ---------- actions ----------
    private fun openApp(name: String, l: Lang): Result {
        if (name.isBlank()) return fail(l, "Which app?", "कौन सा ऐप?", "کون سی ایپ؟")
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = name.trim().lowercase()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull {
                val lb = it.loadLabel(pm).toString().lowercase()
                lb.contains(q) || (lb.length > 2 && q.contains(lb))
            }
            ?: return fail(l, "I couldn't find an app called $name.", "$name नाम का ऐप नहीं मिला।", "$name نام کی ایپ نہیں ملی۔")
        val label = match.loadLabel(pm).toString()
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return fail(l, "$label can't be opened.", "$label नहीं खुल सकता।", "$label نہیں کھل سکتی۔")
        return if (launch(i)) Result(true, l.t("Opened $label", "$label खोला", "$label کھولا"))
        else fail(l, "Couldn't open $label.", "$label नहीं खुला।", "$label نہیں کھلی۔")
    }

    private fun search(q: String, l: Lang): Result {
        if (q.isBlank()) return fail(l, "What should I search for?", "क्या सर्च करूँ?", "کیا سرچ کروں؟")
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))
        val ok = launch(Intent(Intent.ACTION_VIEW, uri).setPackage("com.android.chrome")) ||
            launch(Intent(Intent.ACTION_VIEW, uri))
        return if (ok) Result(true, l.t("Searched Google for \"$q\"", "Google पर \"$q\" सर्च किया", "Google پر \"$q\" سرچ کیا"))
        else fail(l, "No browser available.", "कोई ब्राउज़र नहीं मिला।", "کوئی براؤزر نہیں ملا۔")
    }

    private fun openUrl(url: String, l: Lang): Result {
        if (!(url.startsWith("https://") || url.startsWith("http://")))
            return fail(l, "That is not a valid web address.", "यह सही वेब पता नहीं है।", "یہ درست ویب ایڈریس نہیں ہے۔")
        val uri = Uri.parse(url)
        val ok = launch(Intent(Intent.ACTION_VIEW, uri).setPackage("com.android.chrome")) ||
            launch(Intent(Intent.ACTION_VIEW, uri))
        return if (ok) Result(true, l.t("Opened the page", "पेज खोला", "صفحہ کھولا"))
        else fail(l, "Couldn't open the page.", "पेज नहीं खुला।", "صفحہ نہیں کھلا۔")
    }

    private fun openSettings(which: String, l: Lang): Result {
        val action = when (which.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return if (launch(Intent(action))) Result(true, l.t("Opened settings", "सेटिंग्स खोलीं", "سیٹنگز کھولیں"))
        else fail(l, "Couldn't open settings.", "सेटिंग्स नहीं खुलीं।", "سیٹنگز نہیں کھلیں۔")
    }

    private fun showContacts(l: Lang): Result =
        if (launch(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)))
            Result(true, l.t("Opened contacts", "संपर्क खोले", "رابطے کھولے"))
        else fail(l, "No contacts app found.", "संपर्क ऐप नहीं मिला।", "رابطوں کی ایپ نہیں ملی۔")

    private fun findContacts(name: String): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        )?.use { c ->
            while (c.moveToNext() && out.size < 10) out.add((c.getString(0) ?: "") to (c.getString(1) ?: ""))
        }
        return out
    }

    private suspend fun resolveNumber(contact: String, l: Lang, ensure: suspend (String) -> Boolean): Resolved {
        if (contact.isBlank()) return Resolved(null, l.t("Whose number?", "किसका नंबर?", "کس کا نمبر؟"), notFound = true)
        if (contact.count { it.isDigit() } >= 6 && contact.all { it.isDigit() || it in "+-() " })
            return Resolved(contact.filter { it.isDigit() || it == '+' }, null)
        if (!ensure(Manifest.permission.READ_CONTACTS))
            return Resolved(null, l.t("I need contacts permission to find $contact.", "$contact को ढूँढने के लिए संपर्क की अनुमति चाहिए।", "$contact کو ڈھونڈنے کے لیے رابطوں کی اجازت چاہیے۔"))
        val found = findContacts(contact).distinctBy { it.second.filter(Char::isDigit) }
        return when {
            found.isEmpty() -> Resolved(null, l.t("No contact named $contact.", "$contact नाम का कोई संपर्क नहीं मिला।", "$contact نام کا کوئی رابطہ نہیں ملا۔"), notFound = true)
            found.size > 1 -> {
                val names = found.map { it.first }.distinct().take(4).joinToString(", ")
                Resolved(null, l.t("Several matches: $names. Please say the full name.", "कई नाम मिले: $names। पूरा नाम बोलें।", "کئی نام ملے: $names۔ پورا نام بولیں۔"))
            }
            else -> Resolved(found[0].second, null)
        }
    }

    private suspend fun call(a: Action, l: Lang, ensure: suspend (String) -> Boolean): Result {
        val r = resolveNumber(a.contact, l, ensure)
        if (r.number == null) return Result(false, r.error ?: "")
        if (!ensure(Manifest.permission.CALL_PHONE))
            return fail(l, "Call permission was not granted.", "कॉल की अनुमति नहीं मिली।", "کال کی اجازت نہیں ملی۔")
        return if (launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(r.number)))))
            Result(true, l.t("Calling ${a.contact}", "${a.contact} को कॉल लगाई", "${a.contact} کو کال ملائی"))
        else fail(l, "Couldn't start the call.", "कॉल नहीं लगी।", "کال نہیں لگی۔")
    }

    private suspend fun whatsapp(a: Action, l: Lang, ensure: suspend (String) -> Boolean): Result {
        val pkg = waPackages.firstOrNull { installed(it) }
            ?: return fail(l, "WhatsApp is not installed.", "WhatsApp इंस्टॉल नहीं है।", "WhatsApp انسٹال نہیں ہے۔")
        var number: String? = null
        if (a.contact.isNotBlank()) {
            val r = resolveNumber(a.contact, l, ensure)
            if (r.number != null) number = r.number
            else if (!r.notFound) return Result(false, r.error ?: "")
        }
        val intent = if (number != null) {
            val digits = number.filter { it.isDigit() }
            Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits?text=" + Uri.encode(a.text))).setPackage(pkg)
        } else {
            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.text).setPackage(pkg)
        }
        return if (!launch(intent)) fail(l, "Couldn't open WhatsApp.", "WhatsApp नहीं खुला।", "WhatsApp نہیں کھلا۔")
        else if (number != null) Result(true, l.t(
            "WhatsApp is open with your message ready. Tap Send to send it.",
            "WhatsApp में संदेश तैयार है। भेजने के लिए Send दबाएँ।",
            "WhatsApp میں پیغام تیار ہے۔ بھیجنے کے لیے Send دبائیں۔"))
        else Result(true, l.t(
            "Pick a contact in WhatsApp, then tap Send.",
            "WhatsApp में संपर्क चुनें, फिर Send दबाएँ।",
            "WhatsApp میں رابطہ چنیں، پھر Send دبائیں۔"))
    }

    private fun tiktok(l: Lang): Result {
        val pkg = ttPackages.firstOrNull { installed(it) }
            ?: return fail(l, "TikTok is not installed.", "TikTok इंस्टॉल नहीं है।", "TikTok انسٹال نہیں ہے۔")
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
            ?: return fail(l, "Couldn't open TikTok.", "TikTok नहीं खुला।", "TikTok نہیں کھلا۔")
        return if (launch(i)) Result(true, l.t(
            "TikTok opened. I can't tap inside it, but I can write a caption and copy it for you.",
            "TikTok खुल गया। मैं इसके अंदर टैप नहीं कर सकता, पर कैप्शन लिखकर कॉपी कर सकता हूँ।",
            "TikTok کھل گیا۔ میں اس کے اندر ٹیپ نہیں کر سکتا، مگر کیپشن لکھ کر کاپی کر سکتا ہوں۔"))
        else fail(l, "Couldn't open TikTok.", "TikTok नहीं खुला।", "TikTok نہیں کھلا۔")
    }

    private fun typeText(text: String, l: Lang): Result {
        val svc = AssistAccessibilityService.instance
        if (svc == null) {
            launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return fail(l,
                "Typing needs the ONS PASS AI accessibility service. I opened Accessibility settings. Please enable it.",
                "टाइप करने के लिए ONS PASS AI एक्सेसिबिलिटी सर्विस चाहिए। मैंने सेटिंग्स खोल दी हैं, कृपया इसे चालू करें।",
                "ٹائپ کرنے کے لیے ONS PASS AI ایکسیسبلٹی سروس چاہیے۔ میں نے سیٹنگز کھول دی ہیں، براہ کرم اسے آن کریں۔")
        }
        return if (svc.typeIntoFocused(text)) Result(true, l.t("Typed your text", "आपका टेक्स्ट टाइप किया", "آپ کا متن ٹائپ کیا"))
        else fail(l,
            "No editable text field is focused. Tap the field first.",
            "कोई टेक्स्ट बॉक्स चुना हुआ नहीं है। पहले बॉक्स पर टैप करें।",
            "کوئی ٹیکسٹ باکس منتخب نہیں ہے۔ پہلے باکس پر ٹیپ کریں۔")
    }

    private fun copyText(text: String, l: Lang): Result {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ONS PASS AI", text))
        return Result(true, l.t("Copied. Paste it where you need it.", "कॉपी हो गया। जहाँ चाहिए वहाँ पेस्ट करें।", "کاپی ہو گیا۔ جہاں چاہیے وہاں پیسٹ کریں۔"))
    }
}
