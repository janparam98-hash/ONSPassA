package com.onspass.ai

enum class Lang(val tag: String, val label: String) {
    HI("hi-IN", "हिन्दी"),
    UR("ur-PK", "اردو"),
    EN("en-US", "English")
}

fun Lang.t(en: String, hi: String, ur: String): String = when (this) {
    Lang.EN -> en
    Lang.HI -> hi
    Lang.UR -> ur
}

enum class Status { Idle, Listening, Thinking, Speaking }

data class Msg(val fromUser: Boolean, val text: String, val notice: Boolean = false)

data class Action(
    val type: String,
    val app: String = "",
    val query: String = "",
    val contact: String = "",
    val text: String = "",
    val setting: String = ""
)

data class AiResult(val reply: String, val clarify: Boolean, val actions: List<Action>)
