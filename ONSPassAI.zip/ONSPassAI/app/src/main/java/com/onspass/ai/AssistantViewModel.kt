package com.onspass.ai

import android.Manifest
import android.app.Application
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AssistantViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val executor = ActionExecutor(app)
    private val main = Handler(Looper.getMainLooper())

    val messages = mutableStateListOf<Msg>()
    var status by mutableStateOf(Status.Idle)
        private set
    var partial by mutableStateOf("")
        private set
    var pendingText by mutableStateOf<String?>(null)
        private set
    var lang by mutableStateOf(prefs.lang)
        private set
    var continuous by mutableStateOf(prefs.continuous)
        private set
    var wakeEnabled by mutableStateOf(prefs.wakeEnabled)
        private set
    var wakePhrase by mutableStateOf(prefs.wakePhrase)
        private set
    var hasKey by mutableStateOf(prefs.apiKey.isNotBlank())
        private set

    /** Set by the Activity. Asks for a runtime permission and returns whether it was granted. */
    var ensurePermission: (suspend (String) -> Boolean)? = null
    var foreground = false

    private var pending: Action? = null
    private val queue = ArrayDeque<Action>()
    private var awake = false
    private var suspended = false
    private var ttsWarned = false
    private var afterSpeech: (() -> Unit)? = null

    private val tts = TtsManager(app) { main.post { finishSpeech() } }
    private val speech = SpeechManager(
        app,
        onPart = { partial = it },
        onFinal = { onSpeechResult(it) },
        onFail = { onSpeechFail(it) }
    )

    // ---------------- settings ----------------
    fun updateLang(l: Lang) { lang = l; prefs.lang = l }
    fun updateContinuous(v: Boolean) { continuous = v; prefs.continuous = v; suspended = false; if (v) resumeListening() else stopAll() }
    fun updateWakeEnabled(v: Boolean) { wakeEnabled = v; prefs.wakeEnabled = v }
    fun updateWakePhrase(v: String) { wakePhrase = v; prefs.wakePhrase = v }
    fun saveApiKey(k: String) { prefs.apiKey = k; hasKey = prefs.apiKey.isNotBlank() }
    fun clearHistory() { messages.clear() }

    // ---------------- lifecycle ----------------
    fun onBackground() { speech.stop(); if (status == Status.Listening) status = Status.Idle; partial = "" }
    fun onForeground() { if (status == Status.Idle) resumeListening() }
    override fun onCleared() { speech.stop(); tts.shutdown() }

    // ---------------- mic ----------------
    fun onMicClick() {
        if (status != Status.Idle) { suspended = true; stopAll(); return }
        suspended = false
        startListening()
    }

    private fun stopAll() {
        speech.stop(); tts.stop(); queue.clear(); afterSpeech = null; awake = false
        partial = ""; status = Status.Idle
    }

    private fun startListening() {
        if (status == Status.Listening) return
        viewModelScope.launch {
            val ok = ensurePermission?.invoke(Manifest.permission.RECORD_AUDIO) ?: false
            if (!ok) {
                notice(lang.t("Microphone permission is needed to listen.", "सुनने के लिए माइक्रोफ़ोन की अनुमति चाहिए।", "سننے کے لیے مائیکروفون کی اجازت چاہیے۔"))
                return@launch
            }
            tts.stop(); partial = ""; status = Status.Listening
            speech.start(lang.tag)
        }
    }

    private fun resumeListening() {
        if (!continuous || suspended || !foreground) return
        main.postDelayed({ if (continuous && !suspended && foreground && status == Status.Idle) startListening() }, 400)
    }

    private fun listenOnce() { if (foreground) startListening() }

    // ---------------- speech callbacks ----------------
    private fun onSpeechFail(code: Int) {
        partial = ""; status = Status.Idle
        val benign = code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
        if (benign) { if (pending == null) resumeListening(); return }
        suspended = true
        notice(lang.t(
            "Speech recognition problem (code $code). Check internet and that the Google speech service supports ${lang.label}.",
            "आवाज़ पहचानने में समस्या (कोड $code)। इंटरनेट और Google स्पीच सर्विस की जाँच करें।",
            "آواز پہچاننے میں مسئلہ (کوڈ $code)۔ انٹرنیٹ اور Google اسپیچ سروس چیک کریں۔"))
    }

    private fun onSpeechResult(text: String) {
        partial = ""; status = Status.Idle
        if (pending != null) { handleConfirmationText(text); return }
        if (wakeEnabled && continuous && !awake) {
            val w = wakePhrase.trim().lowercase()
            val idx = if (w.isEmpty()) -1 else text.lowercase().indexOf(w)
            if (idx < 0) { resumeListening(); return }
            val rest = text.substring(idx + w.length).trim(' ', ',', '،', '.')
            if (rest.isEmpty()) {
                awake = true
                say(lang.t("Yes?", "जी?", "جی؟")) { listenOnce() }
            } else process(rest)
        } else {
            awake = false
            process(text)
        }
    }

    // ---------------- confirmation ----------------
    private val yes = setOf("yes", "yeah", "ok", "okay", "confirm", "sure", "haan", "han", "ji", "हाँ", "हां", "जी", "ठीक", "करो", "ہاں", "جی", "ٹھیک", "کرو")
    private val no = setOf("no", "cancel", "stop", "nahi", "nahin", "नहीं", "नही", "रुको", "نہیں", "نہی", "رکو", "کینسل")

    private fun handleConfirmationText(text: String) {
        val tokens = text.lowercase().split(' ', ',', '.', '،', '।').filter { it.isNotBlank() }
        when {
            tokens.any { it in no } -> cancel()
            tokens.any { it in yes } -> confirm()
            else -> say(pendingText ?: "") { listenOnce() }
        }
    }

    fun confirm() {
        val a = pending ?: return
        pending = null; pendingText = null
        execute(a)
    }

    fun cancel() {
        pending = null; pendingText = null; queue.clear()
        say(lang.t("Cancelled.", "रद्द कर दिया।", "منسوخ کر دیا۔")) { resumeListening() }
    }

    // ---------------- AI flow ----------------
    private fun process(text: String) {
        messages.add(Msg(true, text))
        val key = prefs.apiKey
        if (key.isBlank()) {
            say(lang.t("Please add your Gemini API key in Settings.", "कृपया सेटिंग्स में अपनी Gemini API कुंजी डालें।", "براہ کرم سیٹنگز میں اپنی Gemini API کلید ڈالیں۔"))
            return
        }
        status = Status.Thinking
        val hist = messages.filter { !it.notice }.takeLast(12).map { it.fromUser to it.text }.dropWhile { !it.first }
        viewModelScope.launch {
            try {
                val r = GeminiClient.ask(key, hist, lang)
                queue.clear()
                if (!r.clarify) queue.addAll(r.actions)
                val next = { if (r.clarify) listenOnce() else runQueue() }
                if (r.reply.isNotBlank()) say(r.reply) { next() } else next()
            } catch (e: Exception) {
                say(lang.t(
                    "I couldn't reach Gemini. Check your internet connection and API key.",
                    "Gemini से जुड़ नहीं पाया। इंटरनेट और API कुंजी जाँचें।",
                    "Gemini سے رابطہ نہیں ہو سکا۔ انٹرنیٹ اور API کلید چیک کریں۔")) { resumeListening() }
            }
        }
    }

    private fun runQueue() {
        val a = queue.removeFirstOrNull()
        if (a == null) { status = Status.Idle; resumeListening(); return }
        if (executor.needsConfirmation(a)) {
            pending = a
            val q = executor.describe(a, lang) + " " + lang.t("Say yes or no.", "हाँ या नहीं बोलें।", "ہاں یا نہیں بولیں۔")
            pendingText = q
            say(q) { listenOnce() }
        } else execute(a)
    }

    private fun execute(a: Action) {
        viewModelScope.launch {
            status = Status.Thinking
            val r = executor.execute(a, lang) { p -> ensurePermission?.invoke(p) ?: false }
            if (!r.ok) {
                queue.clear()
                say(r.message) { resumeListening() }
                return@launch
            }
            notice("✓ " + r.message)
            if (queue.isNotEmpty()) delay(1800) // let the opened app come to the front
            runQueue()
        }
    }

    // ---------------- output ----------------
    private fun notice(t: String) { messages.add(Msg(false, t, notice = true)); status = Status.Idle }

    private fun say(text: String, then: (() -> Unit)? = null) {
        messages.add(Msg(false, text))
        status = Status.Speaking
        afterSpeech = then
        val ok = tts.speak(text, lang)
        if (!ok) {
            if (!ttsWarned) {
                ttsWarned = true
                messages.add(Msg(false, lang.t(
                    "Spoken replies are unavailable. Install the ${lang.label} voice in Google Text-to-speech settings. Replies still show as text.",
                    "बोलकर जवाब उपलब्ध नहीं। Google Text-to-speech में ${lang.label} आवाज़ इंस्टॉल करें। जवाब टेक्स्ट में दिखेंगे।",
                    "بول کر جواب دستیاب نہیں۔ Google Text-to-speech میں ${lang.label} آواز انسٹال کریں۔ جواب متن میں نظر آئیں گے۔"), notice = true))
            }
            finishSpeech()
        }
    }

    private fun finishSpeech() {
        if (status == Status.Speaking) status = Status.Idle
        val a = afterSpeech
        afterSpeech = null
        a?.invoke()
    }
}
