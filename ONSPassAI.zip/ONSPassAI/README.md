# ONS PASS AI (Android, Kotlin + Jetpack Compose)

Voice assistant for Hindi, Urdu and English, powered by Google Gemini.
Android 12+ (minSdk 31).

## Build the APK
1. Install Android Studio (Koala or newer). Open the `ONSPassAI` folder. It downloads Gradle and the Android SDK, and creates the Gradle wrapper.
2. Press the green Run button with your phone connected (USB debugging on), or build a file:
   - Menu: Build > Build Bundle(s) / APK(s) > Build APK(s)
   - or terminal: `./gradlew assembleDebug`
3. APK location: `app/build/outputs/apk/debug/app-debug.apk`. Copy it to the phone and install it (allow "install unknown apps").

## First run
1. Settings (gear icon) > paste your Gemini API key from https://aistudio.google.com > Save key.
2. Pick Hindi, Urdu or English.
3. Tap the mic and speak, for example:
   - "Chrome खोलो और मौसम सर्च करो"
   - "WhatsApp पर Ali को लिखो मैं आ रहा हूँ"
   - "Ali کو کال کرو"
   - "TikTok के लिए एक छोटा कैप्शन लिखो और कॉपी करो"
4. For typing into other apps: Settings > Open Accessibility settings > ONS PASS AI > turn on.

## What it does and does not do
- Opens installed apps, Chrome/Google searches, phone settings and contacts using normal Android Intents.
- Calls and WhatsApp messages always ask for your yes/no first. For WhatsApp it opens a chat with the text filled in; you tap Send. It never sends by itself.
- TikTok: opens the app and prepares/copies captions. It does not tap buttons inside TikTok.
- Typing and form filling: only into the text field you have already selected, and only if you enabled the accessibility service.
- Listening works while the app is on screen. Android 12+ blocks microphone use by background apps, so after the assistant opens another app, tap back into ONS PASS AI to continue.
- Wake phrase is matched in the recognised text while "keep listening" is on. It is not an always-on hotword engine.
- Spoken replies need the Hindi/Urdu voice installed in Google Text-to-speech. If missing, replies appear as text and the app says so.
- WhatsApp numbers need country codes (e.g. +92...). Contacts saved without them may open the wrong chat.

## API key security
The key is typed once and stored with EncryptedSharedPreferences (Android Keystore). It is sent only to Google in an HTTPS header. For a public release, route calls through your own backend or Firebase AI Logic so no key lives on devices.
