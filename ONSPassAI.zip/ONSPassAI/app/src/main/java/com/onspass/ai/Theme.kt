package com.onspass.ai

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun OnsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF7B5CFF),
            background = Color(0xFF0B0B1A),
            surface = Color(0xFF1A1633),
            onSurface = Color.White,
            onBackground = Color.White
        ),
        content = content
    )
}
