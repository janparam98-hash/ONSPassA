package com.onspass.ai

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: AssistantViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf("") }
    var phrase by remember { mutableStateOf(vm.wakePhrase) }

    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            Text("Settings", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        Text("Language / भाषा / زبان", color = Color(0xFFB9B4FF), fontWeight = FontWeight.SemiBold)
        Lang.values().forEach { l ->
            Row(Modifier.fillMaxWidth().clickable { vm.updateLang(l) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = vm.lang == l, onClick = { vm.updateLang(l) })
                Text(l.label, color = Color.White, fontSize = 17.sp)
            }
        }

        Text("Listening", color = Color(0xFFB9B4FF), fontWeight = FontWeight.SemiBold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Keep listening while the app is open", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = vm.continuous, onCheckedChange = { vm.updateContinuous(it) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Wake phrase (needs the option above)", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = vm.wakeEnabled, onCheckedChange = { vm.updateWakeEnabled(it) })
        }
        OutlinedTextField(
            value = phrase,
            onValueChange = { phrase = it; vm.updateWakePhrase(it) },
            label = { Text("Wake phrase, e.g. hey ons") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Text("Gemini API key", color = Color(0xFFB9B4FF), fontWeight = FontWeight.SemiBold)
        Text(
            if (vm.hasKey) "A key is saved (encrypted on this phone)." else "No key saved yet. Create one free at aistudio.google.com.",
            color = Color(0xFF8E8AB8), fontSize = 13.sp
        )
        OutlinedTextField(
            value = key, onValueChange = { key = it },
            label = { Text("Paste API key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { vm.saveApiKey(key); key = "" }, enabled = key.isNotBlank()) { Text("Save key") }

        Text("Typing into other apps", color = Color(0xFFB9B4FF), fontWeight = FontWeight.SemiBold)
        Text(
            "Optional. Enable the ONS PASS AI accessibility service so dictated text can be typed into the field you have selected. It is off until you turn it on.",
            color = Color(0xFF8E8AB8), fontSize = 13.sp
        )
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Open Accessibility settings", color = Color.White) }

        OutlinedButton(onClick = { vm.clearHistory() }) { Text("Clear conversation", color = Color.White) }
    }
}
