package com.onspass.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    // Change here if Google retires this model name.
    private const val MODEL = "gemini-2.5-flash"

    private fun systemPrompt(lang: Lang) = """
You are ONS PASS AI, a voice assistant inside an Android app. The user speaks Hindi, Urdu or English.
Reply in the same language the user used (Hindi in Devanagari script, Urdu in Urdu script, English in English). Default language: ${lang.label}. Keep replies to 1-2 short sentences because they are spoken aloud.
Return ONLY JSON of this shape:
{"reply":"spoken reply","clarify":false,"actions":[{"type":"...","app":"","query":"","contact":"","text":"","setting":""}]}
Action types:
- open_app (app = app name in English letters, e.g. "WhatsApp", "Camera", "YouTube")
- google_search (query)
- open_url (query = full https URL)
- open_settings (setting = wifi|bluetooth|display|sound|battery|apps|location|accessibility|general)
- show_contacts
- call (contact = saved name or phone number)
- whatsapp (contact = saved name or number, may be empty; text = the message)
- tiktok
- type_text (text = text to type into the field the user has focused)
- copy_text (text = text to copy to clipboard, e.g. a caption)
- none
Rules:
- For multi-step commands return several actions in order.
- Never claim an action already succeeded. The app runs the actions afterwards and reports failures itself. Say what you are about to do, e.g. "Opening Chrome".
- The app itself asks the user to confirm calls and WhatsApp messages.
- If the request is unclear or missing details, set clarify=true, ask ONE short question in reply and return no actions.
- For plain questions, just answer in reply with no actions.
- Never invent phone numbers.
""".trimIndent()

    suspend fun ask(apiKey: String, history: List<Pair<Boolean, String>>, lang: Lang): AiResult =
        withContext(Dispatchers.IO) {
            val contents = JSONArray()
            history.forEach { (fromUser, text) ->
                contents.put(
                    JSONObject()
                        .put("role", if (fromUser) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt(lang)))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("temperature", 0.4).put("responseMimeType", "application/json"))

            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
                .openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 40000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", apiKey) // header, not URL, so it is not logged in URLs
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                if (code !in 200..299) throw IOException("Gemini HTTP $code")
                val raw = conn.inputStream.bufferedReader().use { it.readText() }
                parse(raw)
            } finally {
                conn.disconnect()
            }
        }

    private fun parse(raw: String): AiResult {
        val text = JSONObject(raw)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text").trim()
            .removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val j = try { JSONObject(text) } catch (e: Exception) {
            return AiResult(text, false, emptyList())
        }
        val actions = mutableListOf<Action>()
        val arr = j.optJSONArray("actions")
        if (arr != null) for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            actions.add(
                Action(
                    type = a.optString("type"), app = a.optString("app"), query = a.optString("query"),
                    contact = a.optString("contact"), text = a.optString("text"), setting = a.optString("setting")
                )
            )
        }
        return AiResult(j.optString("reply"), j.optBoolean("clarify", false), actions)
    }
}
