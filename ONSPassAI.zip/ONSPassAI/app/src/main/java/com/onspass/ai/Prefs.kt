package com.onspass.ai

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** All settings live in EncryptedSharedPreferences (AES-256, key held in Android Keystore). */
class Prefs(ctx: Context) {
    private val sp = EncryptedSharedPreferences.create(
        ctx,
        "ons_secure_prefs",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) { sp.edit().putString("api_key", v.trim()).apply() }

    var lang: Lang
        get() = runCatching { Lang.valueOf(sp.getString("lang", "HI") ?: "HI") }.getOrDefault(Lang.HI)
        set(v) { sp.edit().putString("lang", v.name).apply() }

    var continuous: Boolean
        get() = sp.getBoolean("continuous", false)
        set(v) { sp.edit().putBoolean("continuous", v).apply() }

    var wakeEnabled: Boolean
        get() = sp.getBoolean("wake", false)
        set(v) { sp.edit().putBoolean("wake", v).apply() }

    var wakePhrase: String
        get() = sp.getString("wake_phrase", "hey ons") ?: "hey ons"
        set(v) { sp.edit().putString("wake_phrase", v.trim()).apply() }
}
