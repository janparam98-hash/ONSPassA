package com.onspass.ai

import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred

class MainActivity : ComponentActivity() {
    private val vm: AssistantViewModel by viewModels()
    private var permDeferred: CompletableDeferred<Boolean>? = null
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        permDeferred?.complete(it)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        vm.ensurePermission = { p ->
            if (ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED) true
            else {
                val d = CompletableDeferred<Boolean>()
                permDeferred = d
                permLauncher.launch(p)
                d.await()
            }
        }
        setContent { OnsTheme { AssistantApp(vm) } }
    }

    override fun onStart() { super.onStart(); vm.foreground = true; vm.onForeground() }
    override fun onStop() { super.onStop(); vm.foreground = false; vm.onBackground() }
    override fun onDestroy() { if (isFinishing) vm.ensurePermission = null; super.onDestroy() }
}
